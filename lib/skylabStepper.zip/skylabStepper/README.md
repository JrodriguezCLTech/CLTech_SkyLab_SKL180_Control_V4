# Librería skylabStepper

La **librería skylabStepper** fue creada para el control de movimiento de motores paso a paso de manera independiente. El movimiento de los motores se realiza utilizando perfiles de velocidad de aceleración y desaceleración constante, utilizando los cálculos como se describen en el articulo
["Generate stepper-motor speed profiles in real time"](http://web.archive.org/web/20140705143928/http://fab.cba.mit.edu/classes/MIT/961.09/projects/i0/Stepper_Motor_Speed_Profile.pdf).
  
Esta librería no requiere el uso de librerías adicionales, que generen conflictos con otras funcionalidades del MCU. Tampoco requiere el uso de `delay()` por lo que se puede ejectura el control de los motores paso a paso simultáneamente con otros procesos. No hay un número máximo de motores que permite controlar, sin embargo a mayor número de motores trabajando simultáneamente, menores son las velocidades máximas que pueden alcanzar.

Para cada motor se puede configurar como parametros de entrada:
- _ID Motor_ ( `_idMotor` ): ID Motor (0,1,2,...)
- _ID pin dir_ ( `_pinDir` ): Pin MCU conectado al _dir_ driver motor
- _ID pin pul_ ( `_pinPul` ): Pin MCU conectado al _pul_ driver motor
- _ID pin ena_ ( `_pinEna` ): Pin MCU conectado al _ena_ driver motor
- _Pulsos por revolución_ ( `ppr` ): PPR configurados en el driver motor
- _Aceleración motor_ ( `aceleracion` ): Valor aceleración/desaceleración de movimiento motor 
- _RPM máxima motor_ ( `rpmMax` ): Valor máximo de RPM de movimiento motor
- _ID Pin sensor Home_ ( `_pinFinCarrera` ): Pin MCU conectado al sensor final de carrera _home_ 
- _Dirección Home_ ( `dir_home` ): Sentido de giro hacia Home
- _Estado activo sensor Home_ ( `estado_act_sensor` ): Polaridad del sensor de final de carrera cuando este es accionado
- _RPM media motor_ ( `rpmMedia` ): Valor medio de RPM de movimiento motor. Valor recomendado a usar cuando se realiza movimiento simultáneo de 2 o más motores (configurar de acuerdo al rendimiento del MCU y programa ejecutado)
- _RPM baja motor_ ( `rpmBaja` ): Valor bajo de RPM de movimiento motor. Valor utilizados automáticamente cuando el programa detecta cercanía a Home (configurar de acuerdo al programa ejecutado)
- _Max. Tick Avance_ ( `maxMovAxis` ): Valor máximo de ticks a moverse alejandose de home (configurar de acuerdo a la máquina usada, para que no choque con el limite opuesto a home)

**Nota**: No usar estas palabras claves para evitar conflictos con librería.

## Modo de Uso
Hay 2 modos de funcionamiento:
- _Modo normal_: Control de motor/es sin sensores adicionales ni límites en el número de ticks a avanzar. Permite la configuración de la velocidad y aceleración de movimiento, usando (o no) los perfiles de aceleración y desaceleración. Además de movimiento de un número determinado de ticks (con relación a un estado inicial) y un movimiento contínuo en una dirección determinada
- _Modo CNC_: Control de motor/es utilizando sensor que monitoree la llegada a home, además de todas las configuraciones y funcionalidades del _Modo Normal_. Permite la configuración

Además, hay 2 modos de declaraciones:
- _Modo normal_: Declaración objeto `skylabStepper()` y configuración modo CNC con método `configurarCNC()` (opcional), definiendo manualmente todos los parámetros solicitados.
- _Modo simplificado_: Declaración objeto `skylabStepper()` y configuración modo CNC con método `configurarCNCSimp()` (opcional), utilizando una lista de parámetros predefinidos para productos SKYLAB. Los perfiles predefinidos son:
  - `skylabSKL180EjeX = 0` : Eje X SKL-180
  - `skylabSKL180EjeY = 1` : Eje Y SKL-180
  - `skylabSITMCNCEjeX = 2` : Eje X SITM
  - `skylabSITMCNCEjeY = 3` : Eje Y SITM
  - `skylabSITMCNCEjeZ = 4` : Eje Z SITM
  - `skylabSITMMinibanda = 5` : Minibanda SITM

## Instalación
### Forma 1: Software Arduino IDE
1. Descargar _.zip_: Solicitar .zip al responsable en CLTech.
2. Abrir el _software Arduino IDE_. Ingrese al menu _Programa > Incluir Librería > Añadir librería .ZIP_. 
3. Seleccionar el _.zip_ descargado.
### Forma 2: Manual
1. Descargar _.zip_: Solicitar .zip al responsable en CLTech.
2. Mover _.zip_ a la dirección _C:\Users\XXX\Documents\Arduino\libraries_.
3. Descomprimir _.zip_ y renombrar carpeta como _skylabStepper_.

## Requisitos
No se necesita librerías adicionales para funcionar

## Ejemplos

En la librería se encuentran 4 ejemplos:

- **_OneStepperNormal_**: Programa que controla el movimiento 1 motor paso a paso, bajo la siguiente rutina:
  - Girar motor en un sentido, por 10 segundos
  - Cambiar sentido motor, y seguir girando por 10 segundos
  - Apagar motor
  - Mover motor 4000 ticks en una dirección
  - Retornar motor a posición original
    
- **_OneStepperCNC_**: Programa que controla el movimiento 1 motor paso a paso, bajo la siguiente rutina:
  - Mover motor 4000 ticks en una dirección, con RPM máxima
  - Retornar motor a posición original, con RPM máxima
  - Mover motor 4000 ticks en una dirección, con RPM media
  - Retornar motor a posición original, con RPM media
  - Mover motor 4000 ticks en una dirección, con RPM baja
  - Retornar motor a posición original, con RPM máxima

- **_OneStepperNormalSimplificado_**: Programa con funcionalidad similar a _OneStepperNormal_, sin embargo la declaración se realiza en modo simplificado (utilizando parámetros predefinidos en la librería)
    
- **_OneStepperCNCSimplificado_**: Programa con funcionalidad similar a _OneStepperCNC_, sin embargo la declaración se realiza en modo simplificado (utilizando parámetros predefinidos en la librería)
  
## ¿Cómo usarlo?

### 1. Inicialización

En primer lugar incluya la librería en el proyecto:

```cpp
#include <skylabStepper.h>
```

Luego se procede a crear el objeto `skylabStepper` (fuera del `setup()` y `loop()` ) ingresando los parámetros de entrada. Hay dos constructores el completo y simmplificado:

### _Completo:_

```cpp
skylabStepper Stepper (id_motor, _pinDir, _pinPul, _pinEna, ppr, aceleracion, rpmMax);
```
### _Simplificado:_
```cpp
skylabStepper Stepper (MotorConfiguration, id_motor, _pinDir, _pinPul, _pinEna);
```

### 2. Comandos de modos de funcionamiento:

Si se desea configurar el motor bajo el modo CNC se debe utilizar la función `configurarCNC()` ingresando los parámetros de entrada. Hay dos constructores el completo y simplificado:

### _Completo:_
```cpp
Stepper.configurarCNC(pin_fin_carrera, dir_home, estado_act_sensor, avance_, rpm_media, rpm_baja, max_mov_axis);
```
### _Simplificado:_
```cpp
Stepper.configurarCNCSimp(pin_fin_carrera, dir_home, estado_act_sensor);
```

### 3. Comandos de movimiento:

Si se desea que el motor empiece a girar continuamente se utiliza el método `moverMotorFin(sentido)`, donde `sentido` es la dirección de giro del motor que se desea (_0_ ó _1_, la correspondencia con el sentido de giro MR o CMR, depende del driver utilizado). Cuando se configura previamente el motor en modo _CNC_, el _0_ es el sentido de giro hacia el home. En caso tal de ingresar el comando mientras gira en la misma dirección, entonces el motor parará de girar. En caso tal de ingresar el comando mientras gira en la dirección contraria, entonces el motor realizará el cambio de sentido de giro con sus respectivos perfiles de desaceleración y aceleración correspondientes.

```cpp
Stepper.moverMotorFin(0);
Stepper.moverMotorFin(1);
```

Si se desea que el motor se mueva a una posición _[ticks]_ determinada, se utiliza el método `moverMotor(ticks)`, donde `ticks` es la posición en _[ticks]_ a la cual se desea mover. Internamente este método calcula la cantidad de _ticks_ y el sentido de giro al cual se debe mover, teniendo en cuenta la posición actual del motor. En caso de estar en modo CNC entonces el motor automáticamente limita el movimiento, de acuerdo al `maxMovAxis` ingresado.

```cpp
Stepper.moverMotor(0);
Stepper.moverMotor(1000);
Stepper.moverMotor(10000);
```

En caso de tener activado el modo CNC, si se desea que el motor se mueva a la posición de _home_, se utiliza el método `homeMotorFin()`. Esté método hará que el motor comience a retornar en dirección al sensor (`dirHome`) y cuando este detecte que se ha activado entonces parará el movimiento. 

```cpp
Stepper.homeMotorFin();
```

### 4. Comandos de cambios de parámetros:

Este comando se ingresa en caso de necesitar cambiar las RPM movimiento del motor ( `rpmActual` ). En caso tal que el movimiento esté actualmente el movimiento, entonces este realiza la aceleración y desaceleración respectiva para mantener el movimiento con la nuevas RPM ingresadas.

```cpp
Stepper.cambiarRpmActualMotor(rpm);
```

Este comando se ingresa en caso de necesitar cambiar la aceleración del motor. Este cambio solo surte efecto desde que se lleva las RPM a 0.

```cpp
Stepper.cambiarAcelMotor(aceleracion);
```

### 5. Atributos relevantes:

- `(bool) Stepper.estadoMov`: Indica el estado de movimiento del motor. `0` es motor parado, `1` haciendo movimiento `moverMotor`, `2` haciendo movimiento `moverMotorFin`
- `(bool) Stepper.home`: Indica si el motor está en proceso de devolverse a _Home_
- `(long) Stepper.actualPasos`: Indica la posición relativa del motor (en pasos). Al inicio de la ejecución del programa tiene valor de `0`
- `(double) Stepper.rpmActual`: Indica la velocidad (RPM) actual del motor (si está acelerando o frenando este sera la velocidad objetivo)
- `(bool) Stepper.dirHome`: Indica la dirección de giro al cual el motor se moverá al mandar el comando `Stepper.homeMotorFin()`. Y es con relación a este se calculará si atributos como `Stepper.actualPasos`
- `(bool) Stepper.monitorearSensor`: Bandera que indica si se está monitoreando los sensores. De manera predeterminada es `true`
- `(bool) Stepper.velYaReducida`: Bandera que indica si ya se redujo la velocidad del motor a `rpmBaja` cuando está regresando a _home_. El valor predeterminado es `false`, sin embargo si se activa en algun momento del movimiento a _home_, entonces no se va a reducir la velocidad en ningun momento (esto es crítico al manejar velocidades altas, ya que al llegar a _home_ frena en seco)
- `(bool) Stepper.reiniciarPasos`: Bandera que indica si se va a resetear los pasos al llegar a Home. El valor predeterminadon es `true`
- `(bool) Stepper.finCarreraDetectado`: Bandera que indica si el sensor de final de carrera está accionado