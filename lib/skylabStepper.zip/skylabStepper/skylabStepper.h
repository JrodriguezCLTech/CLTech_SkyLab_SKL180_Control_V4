/*
  skylanStepper.h - Library for controling Stepper Motors using David Austin Algoritm for generation of speed profile in real time
  Created by Ing. Jesus D. Caballero. Abril, 2023.
  This code is property of Clinical Laboratory Technology LTDA, CLTech LTDA. Bogotá DC, Colombia.
  CLTECH © 2023

  The standard Arduino IDE includes the Stepper library (http://arduino.cc/en/Reference/Stepper) for stepper motors. It is 
  perfectly adequate for simple, single motor applications.

  Another option is using the AccelStepper library that support multiple simultaneous steppers, with differents configurations
  but this one has problems with high accelerations and desaccelerations, and its very limited with high speed
  
  skylabStepper significantly improves on the standard Arduino Stepper library and AccelStepper library in several ways:
  - No functions use delay(), only use ISR of internal clock of Arduino
  - Support using of CNC configuration: Using limit switch sensors (for Home), and self-calibration
  - Can reach high speeds
  - Can use high acceleration and desacceleration
  
  Example Arduino programs are included to show the main modes of use.

  Installation:
  Install in the usual way: unzip the distribution zip file to the libraries sub-folder of your sketchbook. 
  
  Theory:
  This code uses speed calculations as described in "Generate stepper-motor speed profiles in real time" by David Austin
  http://web.archive.org/web/20140705143928/http://fab.cba.mit.edu/classes/MIT/961.09/projects/i0/Stepper_Motor_Speed_Profile.pdf with 
  An initial step interval is enteis entered by the user (parameter aceleracion). On subsequent steps, shorter step intervals are calculated based 
  on the previous step until max speed is achieved, and the equation in the article
*/

#ifndef skylabStepper_h_
#define skylabStepper_h_

#include <Arduino.h>

class skylabStepper {
private:
    // VARIABLES ESTADO MOTOR
    char estadoAccel;                           // [1] ACELERANDO, [2] DESACELERANDO, [0] RPM CONSTANTE 
    char estadoEspecial;                        // [1] DISMINUYENDO RPM (PERO NO TOTALMENTE), [2] CAMBIANDO SENTODP GIRO (CUANDO SE SOLICITA GIRAR PERO A OTRO SENTIDO DE GIRO), [0] NINGUNA DE LAS DOS
    bool sentido;                               // SENTIDO DE GIRO ([0] AVANZANDO, [1] RETROCEDIENDO)
    bool calibrandoHome;                        // ESTADO DE MOTOR DE CALIBRANDO HOME CUANDO LLEGA MUY RAPIDO ([0] NO CALIBRANDO HOME, [1] CALIBRANDO HOME)

    // VARIABLES AUXILIARES CONTROL DE VELOCIDAD DE MOTOR
    unsigned long microsAnterior[2];            // INSTANTE TIEMPO DE ANTERIOR PULSO
    unsigned long nIteraciones;                 // NUMERO ITERACIONES UTILIZADAS EN ACELERACIÓN
    long cercaHome;
    unsigned long dSensor;
    unsigned long dSensorMax;
    unsigned long dSensorMin;
    double coefDistancia;
    
    // VARIABLES AUXILIARES LECTURA SENSOR
    unsigned long tempCambioSensor;             // TIEMPO (EN MILLIS) CUANDO SE PROCESÓ POR ÚLTIMA VEZ LAS ÚLTIMAS LECTURAS DEL SENSOR FINAL DE CARRERAS
    bool lecturasFinCarrera[5];                 // ULTIMAS 30 LECTURAS DE SENSOR FINAL DE CARRERA 

    void inicializarArray(bool* boolArray);     // FUNCIÓN PARA INICIALIZAR EN 0 UNA ARRAY DE BOOLEANOS
    void caminoAHome();                         // FUNCIÓN PARA PROCESAR EL PROCESOS A REALIZAR CUANDO EL MOTOR ESTÁ YENDO A HOME
    void acelerarMotor();                       // FUNCIÓN PARA ACELERAR RPM MOTOR
    void desacelerarMotor();                    // FUNCIÓN PARA DESACELERAR RPM MOTOR
    
public:
    typedef enum
    {
      skylabSKL180EjeX = 0,
      skylabSKL180EjeY = 1,
      skylabSITMCNCEjeX = 2,
      skylabSITMCNCEjeY = 3,
      skylabSITMCNCEjeZ = 4,
      skylabSITMMinibanda = 5,
    } MotorConfiguration;
    
    // PARAMETROS ENTRADA CONSTRUCTOR
    byte _idMotor;
    byte _pinDir;                                // ID PIN DIRECCION
    byte _pinPul;                                // ID PIN PULSOS
    byte _pinEna;                                // ID PIN ENABLE
    uint8_t configuracionMotor;
    double ppr;                                 // PULSOS POR REVOLUCIÓN (PPR) CONFIGURADO EN CADA DRIVER
    double aceleracion;                         // CONSTANTE DE ACELERACIÓN DE MOTORES
    double rpmMax;                              // VALOR RPM DE LOS MOTORES CUANDO REALIZAN MOVIMIENTOS NORMALES (MOVER, GIRAR, HOME)
    
    // PARAMETROS ENTRADA CONFIGURACIÓN CNC
    byte _pinFinCarrera;                         // ID PIN SEÑAL SENSOR FINAL DE CARRERA
    double rpmMedia;                            // VALOR RPM CUANDO SE MUEVEN DOS O TRES EJES SIMULTÁNEAMENTE
    double rpmBaja;                             // VALOR RPM CUANDO PASA CIERTO TIEMPO DESDE QUE EL MOTOR ESTÁ YENDO A HOME 
    double avance;                              // AVANCE MECANISMO CNC [mm/rev] = CUANTOS [mm] AVANZA POR CADA [rev] DEL MOTOR
    long maxMovAxis;                            // MÁXIMO AVANCE [EN PASOS] QUE PUEDE REALIZAR EL MOTOR

    // VARIABLES ESTADO MOVIMIENTO MOTOR
    bool modoCNC;                               // [1] MODO FUNCIONAMIENTO CNC, [0] MODO FUNCIONAMIENTO NORMAL
    char estadoMov;                             // [1] HACIENDO COMANDO ROTAR, [2] HACIENDO COMANDO MOVER, [0] NO HACIENDO NINGUNO DE LOS DOS
    bool home;                                  // ESTADO DE MOVIMIENTO DE EJECUTANDO COMANDO HOME ([0] NO EJECUTANDO, [1] EJECUTANDO)
    bool hacerPerfilVel;

    // VARIABLES AUXILIARES CONTROL DE VELOCIDAD DE MOTOR
    unsigned long T;
    unsigned long dPeriodoPulso;                // PERIODO ENTRE PULSOS ACTUAL (EN MICRAS)
    unsigned long minPeriodo;                   // MINIMO PERIODO ENTRE PULSOS (EN MICRAS, DEPENDIENTE A RPM NOM)
    long actualPasos;                           // UBICACIÓN ABSOLUTA ACTUAL (EN PASOS)
    long acelPasos;                             // PASOS NECESARIOS PARA ACELERAR DE 0 A RPM_NOM
    long movPasos;                              // UBICACIÓN RELATIVA A COMANDO MOV ACTUAL (EN PASOS)
    long totalMovPasos;                         // UBICACIÓN RELATIVA A COMANDO MOV OBJETIVO (EN PASOS)
    long mitadTotalMovPasos;                    // MITAD DE UBICACIÓN RELATIVA A COMANDO MOV OBJETIVO (EN PASOS)
    long totalPasos;                            // UBICACIÓN ABSOLUTA OBJETIVO (EN PASOS)
    double rpmActual;                           // VALOR ACTUAL DE LAS RPM NOMINAL DE LOS MOTORES
    
    // VARIABLES AUXILIARES LLEGADA A HOME
    bool dirHome;
    bool estadoActSensor;
    bool monitorearSensor;
    bool velYaReducida;                         // BANDERA AVISANDO QUE YA SE REDUJO LA VELOCIDAD CUANDO EL MOTOR ESTÁ YENDO A HOME
    bool reiniciarPasos;
    bool salioDeHome;                           // BANDERA AVISANDO QUE YA SALIO DE HOME (SE DESACTIVO EL SENSOR FINAL DE CARRERA EN ALGUN MOMENTO
    
    // VARIABLES AUXILIARES LECTURA SENSOR
    byte sumaLecturasFinCarrera;                // SUMA DE ULTIMAS LECTURAS DE SENSOR FINAL DE CARRERA 
    bool finCarreraDetectado;                   // SE ACTIVÓ SENSOR FINAL DE CARRERA (EJE LLEGÓ A HOME)
    
    // MÉTODOS DE CLASE
    skylabStepper(byte id_motor,byte pin_dir,byte pin_pul,byte pin_ena,double ppr_,double aceleracion_,double rpm_max); // BUILDER
    skylabStepper(uint8_t configuracion,byte id_motor,byte pin_dir,byte pin_pul,byte pin_ena);
    void configurarCNC(byte pin_fin_carrera,bool dir_home,bool estado_act_sensor,double avance_,double rpm_media,double rpm_baja,double max_mov_axis);    //ACTIVAR Y CONFIGURAR MODO CNC
    void configurarCNCSimp(byte pin_fin_carrera,bool dir_home,bool estado_act_sensor);
    void estadoPerfilVel(bool estado);
    void estadoHomePasos(bool estado);
    void configurarMaxMovAxis(long maxMovAxis_);
    double calcularActualPeriodo();             // FUNCIÓN PARA CALCULAR EL MINIMO PERIODO ENTRE PULSOS (VARIABLE minPeriodo)
    double calcularActualRpm();                 // FUNCIÓN PARA CALCULAR RPM ACTUALES (RPM EN ESE INSTANTE DE TIEMPO)
    void resetearBanderasMov();                 // FUNCIÓN PARA RESETEAR LAS BANDERAS DE MOVIMIENTO DEL MOTOR
    void resetearTodasBanderas();               // FUNCIÓN PARA RESETEAR TODAS LAS BANDERAS DEL MOTOR
    void moverMotorFin(bool sentido_);          // FUNCIÓN PARA GIRAR SIN DETENERSE EN UN SENTIDO DETERMINADO
    void moverMotor(double pasos);              // FUNCIÓN PARA GIRAR UNA CANTIDAD DE PASOS DETERMINADOS
    void homeMotorFin();                        // FUNCIÓN PARA LLEVAR A HOME EL MOTOR (DEPENDE DEL FINAL DE CARRERA)

    void cambiarRpmActualMotor(int rpm);        // FUNCIÓN PARA ASIGNAR UN VALOR DETERMINADO A RPM NOMINAL MAXIMO (VARIABLE rpmNom)
    void cambiarAcelMotor(int aceleracion);     // FUNCIÓN PARA ASIGNAR UN VALOR DETERMINADO A ACELERACION
    void filtrarSensorCNC();                    // FUNCIÓN PARA PROCESAR LA LECTURA ACTUAL DEL SENSOR FINAL DE CARRERA
    void procesarCNC();
    void control();                             // FUNCIÓN PARA CONTROLAR LOS PULSOS A MANDAR A LOS MOTORES, ASÍ COMO SU ACELERACIÓN Y DESACELERACIÓN
};


#endif
