/*
  skylabStepper.cpp
  Created by Ing. Jesus D. Caballero. Abril, 2023.
  This code is property of Clinical Laboratory Technology LTDA, CLTech LTDA. Bogotá DC, Colombia.
  CLTECH © 2023
*/

#include "skylabStepper.h"
// SELECCION PPR SEGUN MODELO (SKL-180, ESTACION, ETC)
skylabStepper::skylabStepper(byte id_motor,byte pin_dir,byte pin_pul,byte pin_ena,double ppr_,double aceleracion_,double rpm_max) {
    _idMotor = id_motor;
    _pinDir = pin_dir;
    _pinPul = pin_pul;
    _pinEna = pin_ena;
    pinMode(_pinDir,OUTPUT);
    digitalWrite(_pinDir,LOW);
    pinMode(_pinPul,OUTPUT);
    digitalWrite(_pinPul,LOW);
    pinMode(_pinEna,OUTPUT);

    ppr = ppr_;
    aceleracion = aceleracion_;
    rpmMax = rpm_max;
    rpmActual = rpm_max;
    minPeriodo = calcularActualPeriodo();

    resetearTodasBanderas();
    T = aceleracion;

    finCarreraDetectado = false;
    estadoActSensor = 1;
    dirHome = 1;
    salioDeHome = 0;
    monitorearSensor = true;
    dSensorMax = 50;
    dSensorMin = 10;
    coefDistancia = 0.0001;
    dSensor = dSensorMax;
    microsAnterior[0] = 0;
    microsAnterior[1] = 0;
    hacerPerfilVel = true; 
    cercaHome = rpmActual*aceleracion*0.0001;
    velYaReducida = false;
    reiniciarPasos = true;
    
    modoCNC = false;
    
    inicializarArray(lecturasFinCarrera);
    sumaLecturasFinCarrera = 0;
    
    actualPasos = 0;
}

skylabStepper::skylabStepper(uint8_t configuracion,byte id_motor,byte pin_dir,byte pin_pul,byte pin_ena) {
    configuracionMotor = configuracion;
    _idMotor = id_motor;
    _pinDir = pin_dir;
    _pinPul = pin_pul;
    _pinEna = pin_ena;
    pinMode(_pinDir,OUTPUT);
    digitalWrite(_pinDir,LOW);
    pinMode(_pinPul,OUTPUT);
    digitalWrite(_pinPul,LOW);
    pinMode(_pinEna,OUTPUT);

    switch (configuracionMotor) {
        case 0:
            ppr = 400;
            aceleracion = 7000;
            rpmMax = 3500;
            dSensorMax = 50;
            dSensorMin = 5;
            coefDistancia = 0.000065;
            break;
        case 1:
            ppr = 400;
            aceleracion = 7000;
            rpmMax = 3500;
            dSensorMax = 50;
            dSensorMin = 5;
            coefDistancia = 0.000065;
            break;
        case 2:
            ppr = 800;
            aceleracion = 25000;
            rpmMax = 375;
            dSensorMax = 50;
            dSensorMin = 10;
            coefDistancia = 0.00025;
            break;
        case 3:
            ppr = 800;
            aceleracion = 25000;
            rpmMax = 375;
            dSensorMax = 50;
            dSensorMin = 10;
            coefDistancia = 0.00025;
            break;
        case 4:
            ppr = 800;
            aceleracion = 15000;
            rpmMax = 200;
            dSensorMax = 50;
            dSensorMin = 10;
            coefDistancia = 0.0002;
            break;
        case 5:
            ppr = 400;
            aceleracion = 10000;
            rpmMax = 1000;
            dSensorMax = 50;
            dSensorMin = 10;
            coefDistancia = 0.0001;
            break;
    }

    rpmActual = rpmMax;
    minPeriodo = calcularActualPeriodo();

    resetearTodasBanderas();
    T = aceleracion;

    finCarreraDetectado = false;
    estadoActSensor = 1;
    dirHome = 1;
    salioDeHome = 0;
    monitorearSensor = true;
    dSensor = dSensorMax;
    microsAnterior[0] = 0;
    microsAnterior[1] = 0;
    hacerPerfilVel = true; 
    cercaHome = rpmActual*aceleracion*0.0001;
    velYaReducida = false;
    reiniciarPasos = true;
    
    modoCNC = false;
    
    inicializarArray(lecturasFinCarrera);
    sumaLecturasFinCarrera = 0;
    
    actualPasos = 0;
}

// avance quitar
void skylabStepper::configurarCNC(byte pin_fin_carrera,bool dir_home,bool estado_act_sensor,double avance_,double rpm_media,double rpm_baja,double max_mov_axis) {
    _pinFinCarrera = pin_fin_carrera;
    pinMode(_pinFinCarrera,INPUT);

    dirHome = dir_home;
    estadoActSensor = estado_act_sensor;
    avance = avance_;
    rpmMedia = rpm_media;
    rpmBaja = rpm_baja;
    maxMovAxis = max_mov_axis;

    modoCNC = true;

    for (int i = 0; i < sizeof(lecturasFinCarrera); i++) {
        filtrarSensorCNC();
        delay(10);
    }
}

void skylabStepper::configurarMaxMovAxis(long maxMovAxis_) {
    maxMovAxis = maxMovAxis_;
}

void skylabStepper::configurarCNCSimp(byte pin_fin_carrera,bool dir_home,bool estado_act_sensor) {
    _pinFinCarrera = pin_fin_carrera;
    pinMode(_pinFinCarrera,INPUT);
    
    dirHome = dir_home;
    estadoActSensor = estado_act_sensor;

    switch (configuracionMotor) {
        case 0:
            avance = 20;
            rpmMedia = 3000;
            rpmBaja = 1000;
            maxMovAxis = 18500;
            break;
        case 1:
            avance = 20;
            rpmMedia = 3000;
            rpmBaja = 1000;
            maxMovAxis = 9000;
            break;
        case 2:
            avance = 40;
            rpmMedia = 375;
            rpmBaja = 120;
            maxMovAxis = 11390;
            break;
        case 3:
            avance = 40;
            rpmMedia = 375;
            rpmBaja = 120;
            maxMovAxis = 15000;
            break;
        case 4:
            avance = 40;
            rpmMedia = 200;
            rpmBaja = 60;
            maxMovAxis = 1440;
            break;
        case 5:
            avance = 20;
            rpmMedia = 400;
            rpmBaja = 200;
            maxMovAxis = 10000;
            break;
    }

    modoCNC = true;

    for (int i = 0; i < sizeof(lecturasFinCarrera); i++) {
        filtrarSensorCNC();
        delay(10);
    }
}

void skylabStepper::estadoPerfilVel(bool estado) {
    hacerPerfilVel = estado;
    resetearBanderasMov();
}

void skylabStepper::estadoHomePasos(bool estado) {
    reiniciarPasos = estado;
}

double skylabStepper::calcularActualPeriodo() {
    return (unsigned long)((1000000*60)/(rpmActual*ppr));
}

double skylabStepper::calcularActualRpm() {
    return (1000000*60)/(dPeriodoPulso*ppr);
}

void skylabStepper::resetearBanderasMov() {
    estadoAccel = 0;    // NI ACELERANDO NI DESACELERANDO
    estadoMov = 0;      //NI ROTAR NI MOVER

    dPeriodoPulso = aceleracion;
    T = aceleracion;
    nIteraciones = 0;
    acelPasos = 0;
    movPasos = 0;
    totalMovPasos = 0;
    mitadTotalMovPasos = 0;
    totalPasos = 0;
    dSensor = dSensorMax;
}  

void skylabStepper::resetearTodasBanderas() {
    resetearBanderasMov();
    estadoEspecial = 0; // NI DISMINUYENDO VELOCIDAD NI CAMBIANDO SENTIDO
    home = false;
    calibrandoHome = false;
    velYaReducida = false;
}

void skylabStepper::moverMotorFin(bool sentido_) {
    if (estadoMov == 1 and hacerPerfilVel){
        estadoAccel = 2;
        
        if (sentido != sentido_) {
            estadoEspecial = 2;
        }
    } else {
        estadoAccel = 1;
        dPeriodoPulso = aceleracion;            
        acelPasos = 0;
        movPasos = 0;
        sentido = sentido_;
        digitalWrite(_pinDir,not (dirHome ^ sentido));
    }
    estadoMov = 1;  // ROTAR
    if (modoCNC and monitorearSensor) {
        dSensor = dSensorMin;
    }
}

void skylabStepper::moverMotor(double pasos) {
    resetearBanderasMov();
    estadoMov = 2;  // MOVER

    if (modoCNC and pasos > maxMovAxis) {
        pasos = maxMovAxis;
    }

    totalPasos = pasos;
    totalMovPasos = abs(pasos - actualPasos);
    mitadTotalMovPasos = totalMovPasos *0.5;
    estadoAccel = 1;
    sentido = (pasos - actualPasos > 0 ? 1 : 0);
    digitalWrite(_pinDir,not (dirHome ^ sentido));
    if (modoCNC and monitorearSensor) {
        dSensor = dSensorMin;
    }
}

void skylabStepper::homeMotorFin() {
    moverMotorFin(0);
    home = true;
}

void skylabStepper::cambiarRpmActualMotor(int rpm) {
    rpmActual = abs(rpm);
    minPeriodo = calcularActualPeriodo();
    cercaHome = rpmActual*aceleracion*coefDistancia;

    if (hacerPerfilVel) {
        if (estadoMov == 1) {
            if (calcularActualRpm() < rpm) {
                estadoAccel = 1;
            } else if(calcularActualRpm() > rpm){
                estadoAccel = 2;
                estadoEspecial = 1;
            }
        }
    } else {
        T = minPeriodo;
        if(not home and not modoCNC){
            sentido = rpm>0? 1 : 0;
            digitalWrite(_pinDir,not (dirHome ^ sentido));
        }
    }
}

void skylabStepper::cambiarAcelMotor(int aceleracion) {
    aceleracion = aceleracion;
}

void skylabStepper::filtrarSensorCNC() {
    sumaLecturasFinCarrera -= lecturasFinCarrera[0];
    
    for (int i = 0; i<sizeof(lecturasFinCarrera)-1; i++) {
        lecturasFinCarrera[i] = lecturasFinCarrera[i+1];
    }
    
    lecturasFinCarrera[sizeof(lecturasFinCarrera)-1] = digitalRead(_pinFinCarrera);
    sumaLecturasFinCarrera += lecturasFinCarrera[sizeof(lecturasFinCarrera)-1];

    if (actualPasos<-abs(maxMovAxis)/10) {
        salioDeHome = 1;
    }

    if (estadoActSensor) { 
        if (sumaLecturasFinCarrera >= 4) {
            finCarreraDetectado = true;
        } else if (sumaLecturasFinCarrera <= 1) {
            finCarreraDetectado = false;
            salioDeHome = true;
        }
    } else {
        if (sumaLecturasFinCarrera <= 1) {
            finCarreraDetectado = true;
        } else if (sumaLecturasFinCarrera >= 4) {
            finCarreraDetectado = false;
            salioDeHome = true;
        }
    }
}

void skylabStepper::procesarCNC() {
    if (modoCNC and monitorearSensor and millis() - microsAnterior[0] >= dSensor) {
        microsAnterior[0] = millis(); 
        filtrarSensorCNC();
        caminoAHome();
    }
}

void skylabStepper::control() {    
    if (micros() - microsAnterior[1] >= T) {
        microsAnterior[1] = micros();

        if (not hacerPerfilVel) {
            digitalWrite(_pinPul, 1);
            delayMicroseconds(1);
            digitalWrite(_pinPul, 0);
            actualPasos += (sentido? 1 : -1);
        } else {
            if(estadoMov == 1 or estadoMov == 2 or home){
                digitalWrite(_pinPul, 1);
                delayMicroseconds(1);
                digitalWrite(_pinPul, 0);
                actualPasos += (sentido? 1 : -1);
                movPasos ++;

                if (modoCNC and actualPasos >= maxMovAxis) {
                    //Serial.println("Llego a final");
                    resetearBanderasMov();
                }
                
                switch (estadoAccel) {
                    case 1:                             // ACELERANDO
                        acelerarMotor();
                        break;

                    case 2:                             // DESACELERANDO
                        desacelerarMotor();
                        break;
                
                    default:
                        if (estadoMov == 2 and movPasos >= totalMovPasos - acelPasos){
                            estadoAccel = 2;        
                        }
                        
                        break;
                }
            }
        }

        
    }
}

/* --------------------------------------------------------------------------------------------------
----------------------------------------- METODOS PRIVADOS ------------------------------------------ 
-------------------------------------------------------------------------------------------------- */

void skylabStepper::inicializarArray(bool* boolArray) {
  for (int i = 0; i<sizeof(boolArray);i++) {
    boolArray[i] = 0;
  }
}

// CREAR UN .h CON UN METODO modoDepurar() [Serial.print(estadoInteres)] modoAuto() [no imprimir nada]
void skylabStepper::caminoAHome() {
    if(home and not velYaReducida and not calibrandoHome and actualPasos <=  cercaHome) {
        velYaReducida = true;
        cambiarRpmActualMotor(rpmBaja);
    }

    if (_idMotor == 0 or _idMotor == 1 or _idMotor == 2) {
        if (salioDeHome and finCarreraDetectado and not calibrandoHome) {
            salioDeHome = false;
            resetearBanderasMov();
            //Serial.println(actualPasos);
            if (reiniciarPasos) {
                actualPasos = 0;
            }

            sentido = 0;
            digitalWrite(_pinDir,not (dirHome ^ sentido));
            
            if (not velYaReducida) {
                home = true;
                cambiarRpmActualMotor(rpmBaja);
                
                velYaReducida = true;

                moverMotor(cercaHome);
                hacerPerfilVel = true;
                calibrandoHome = true;
                //Serial.println("Se llego a home muy rapido");
            } else {
                home = false;
                cambiarRpmActualMotor(rpmMax);
                dSensor = dSensorMax;
                velYaReducida = false;

                calibrandoHome = false;
                
                /*switch(_idMotor) {
                    case 0:
                        Serial.println("EJE X llegó a HOME ");
                        break;
                    case 1:
                        Serial.println("EJE Y llegó a HOME ");
                        break;
                    case 2:
                        Serial.println("EJE Z llegó a HOME ");
                        break;
                }*/
            }
            
        }
    } else {
        if (salioDeHome and finCarreraDetectado) {
            salioDeHome = false;
            resetearBanderasMov();
            //Serial.println(actualPasos);
            if (reiniciarPasos) {
                actualPasos = 0;
            }

            sentido = 0;
            digitalWrite(_pinDir,not (dirHome ^ sentido));
            home = false;
            cambiarRpmActualMotor(rpmMax);
            dSensor = dSensorMax;
            velYaReducida = false;
            calibrandoHome = false;
            
            /*switch(_idMotor) {
                case 0:
                    Serial.println("EJE X llegó a HOME ");
                    break;
                case 1:
                    Serial.println("EJE Y llegó a HOME ");
                    break;
                case 2:
                    Serial.println("EJE Z llegó a HOME ");
                    break;
            }*/
            
        }
    }
    
    if (home and calibrandoHome and estadoMov == 0) {
        //Serial.println("Se va a llegar a home por segunda vez");
        calibrandoHome = false;
        velYaReducida = true;
        dSensor = dSensorMin;
        
        resetearBanderasMov();
        cambiarRpmActualMotor(rpmBaja);
        homeMotorFin();
    }
}

// DIVIDIR METODOS IMPLICITOS (ORGANIZARLOS)
void skylabStepper::acelerarMotor() {
    nIteraciones++;
    dPeriodoPulso -= dPeriodoPulso / (2 * nIteraciones + 0.5);
    T = dPeriodoPulso;
    
    // COMPROBAR SI YA LLEGO A VELOCIDAD MAXIMA (EN CASO QUE SÍ, DEBE DEJAR DE ACELERAR)
    if (dPeriodoPulso < minPeriodo){
        dPeriodoPulso = minPeriodo;
        acelPasos = movPasos;
        estadoAccel = 0;
        //Serial.print(_idMotor);
        //Serial.print(": TERMINO ACELERAR HASTA VELOCIDAD MAXIMA dPeriodoPulso: ");
        //Serial.println(dPeriodoPulso);
    }
    
    // COMPROBAR SI YA LLEGO A LA MITAD DEL RECORRIDO (EN CASO QUE SÍ, DEBE COMENZAR A DESACELERAR)
    if (movPasos >= mitadTotalMovPasos and estadoMov == 2){
        acelPasos = movPasos;
        estadoAccel = 2;
        //Serial.print(_idMotor);
        //Serial.print(": TERMINO ACELERAR PORQUE YA ESTA LLEGANDO dPeriodoPulso: ");
        //Serial.println(dPeriodoPulso);
    }
}

void skylabStepper::desacelerarMotor() {
    dPeriodoPulso += dPeriodoPulso / (2 * nIteraciones - 0.5);
    nIteraciones--;
    T = dPeriodoPulso;
    
    // COMPROBAR QUE YA TERMINÓ DE DESCELERAR COMPLETAMENTE
    if (nIteraciones == 0 and estadoEspecial != 1) {
        switch(estadoMov) {
            case 1:
                // COMPROBAR SI ESTA CAMBIANDO DE SENTIDO DE GIRO (EN CASO QUE SI, ACTIVAR GIRO EN SENTIDO CONTRARIO)
                resetearBanderasMov();
                if (estadoEspecial == 2) {
                    estadoEspecial = 0;
                    estadoMov = 1;      // ROTAR
                    estadoAccel = 1;    // ACELERAR
                    sentido = not sentido;
                    digitalWrite(_pinDir,not (dirHome ^ sentido));
                }
                break;
            case 2:
                // COMPROBAR SI ACABA DE TERMINAR DE HACER COMANDO MOVERMOTOR (EN CASO QUE SI, TERMINE MOVIMIENIENTO)
                //Serial.print("Terminó comando MOVER ");
                //Serial.print(_idMotor);
                //Serial.print(" ");
                //Serial.println(int(totalPasos));
                dSensor = dSensorMax;
                
                if (not home and velYaReducida) {
                    velYaReducida = false;
                    cambiarRpmActualMotor(rpmMax);
                }
                resetearBanderasMov();
                break;
        }
        //Serial.println("TERMINO DESACELERAR");
        
    } else if(estadoEspecial == 1 and dPeriodoPulso > minPeriodo) {
        estadoAccel = 0;
        estadoEspecial = 0;
    }
}
