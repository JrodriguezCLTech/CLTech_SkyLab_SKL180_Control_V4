# Control de versionamiento

## Versión Marzo - Abril 2023
- Creación de librería stepper.h
- Implementación de librería `GyversTimers` para la llamada del metodo principal `stepper.control()`. Ventajas: El control de velocidad es muy exacto independiente a los procesos paralelos que se ejecuten. Desventajas: Límites en el número de motores a controlar simultáneamente (1 para Arduino Nano y Uno, 3 para Arduino Mega) e incompatibilidad con librería `servo`
- Implementación de perfil de velocidad (aceleración y desaceleración constante)
- Implementación de 2 modalidades de movimiento: giro continuo y giro por pasos, siguiendo perfil de velocidad

## Versión - Mayo 2023
- Cambio en algoritmo de llamada del método principal para no utilizar librería `GyversTimers`
- Optimización de librería y mejoras drásticas en velocidades máximas alcanzadas
- Cambios menores en código para mejorar distribución de métodos y atributos

## Versión - Junio 2023
- Mejoras en facilidad de uso de librería, implementando modos de funcionamiento (según productos _SKYLAB_)
- Se agrega múltiples banderas y atributos para mejorar el rendimiento de la librería según se requiera en procesos particulares
- Cambios menores en código para mejorar adaptación de librería a los productos _SKYLAB_